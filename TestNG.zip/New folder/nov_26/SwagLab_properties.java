package nov_26;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SwagLab_properties {
  @Test
  public void f() {
	  WebDriver dr = new ChromeDriver();
	  dr.manage().window().maximize();
	  
	  
  }
}
