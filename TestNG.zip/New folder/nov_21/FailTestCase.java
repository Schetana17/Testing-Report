package nov_21;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class FailTestCase {
  @Test
  public void FailTest() {
	  
	  WebDriver dr= new ChromeDriver();
	  dr.get("https://www.saucedemo.com/");
	  dr.findElement(By.id("user-name")).sendKeys("standard_user");
	  dr.findElement(By.xpath("password")).sendKeys("secret_sauce");
	  dr.findElement(By.id("login-button")).click();
  }
}
